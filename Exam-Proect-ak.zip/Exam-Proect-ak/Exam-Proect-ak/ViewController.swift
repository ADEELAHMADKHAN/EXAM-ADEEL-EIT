//
//  ViewController.swift
//  Exam-Proect-ak
//
//  Created by Cosultant on 8/26/22.
//

import UIKit

class ViewController: UIViewController, sendInfo {
    @IBOutlet weak var namePass: UILabel?
    @IBOutlet weak var imagePass: UIImageView?
    var infoShow = ""
    var imageShow = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.namePass?.text = infoShow.capitalized
        self.imagePass?.image = UIImage(named: imageShow)
        self.navigationItem.title = "Detailed Information"
        
        // Do any additional setup after loading the view.
    }
    
}

//MARK: - sendInfo
extension ViewController {
    func details(info1: String, info2: String ){
    self.namePass?.text = info1.capitalized
    self.imagePass?.image = UIImage(named: info2 )
    

}
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "listSegue"{
            //
        }
    }
}

