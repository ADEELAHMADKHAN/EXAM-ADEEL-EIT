//
//  TabTwoViewController.swift
//  Exam-Proect-ak
//
//  Created by Cosultant on 8/26/22.
//
protocol sendInfo {
    func details(info1: String, info2: String )
}

import UIKit

class TabTwoViewController: UIViewController {
    var bandsArray = [bandsList]()
    var delegate: sendInfo?
    
    
    var textDetails = [
"""
The Beatles had a short run of only 10 years from 1960 to 1970, but they're still the best-selling artists of all time by far. If you were to add in their solo albums and side groups, they'll hold that record forever. They started young and led the British Invasion of pop and rock into the USA, and their fans grew up alongside them, purchasing each album as time went on.These guys won all the awards, starred in and produced movies, and even hold records like having the most covered song of all time. The Lennon-McCartney songwriting team is the most successful ever. They had pop appeal, and rock appeal, and evolved through the interests of the hippy era... they're some of the best musicians to ever exist. They're so good that hipsters think it's cool to hate them.
""",
"""
The Rolling Stones are such a big deal that even the members' solo careers, like that of Mick Jagger and Keith Richards, are just as big. They got started in 1962 and were at the forefront of the British Invasion. Of the top 5 highest-grossing tours, four of them belong to this band. Part of their success is attributed to them staying true to the safe foundational genres like R&B, soul, and rock. They even recently won a Grammy Award for Best Traditional Blues Album. Consistency is key when pop music evolves and changes so rapidly, which is why they're still on top after nearly 60 years.
""",
"""
 Even with their early releases led by Syd Barrett, Pink Floyd was already making their mark on the British rock scene. Later, when David Gilmour joined the band and took over the creative direction they gained international recognition. Four of their albums topped both the US and UK charts, though only two of their singles ever reached the top 10 in either region. In a six-decade career, they've released 15 albums and toured to support each release. They even composed film scores for some lesser-known movies. Two of their albums, The Wall and The Dark Side of the Moon are both in the list of the best-selling albums of all time. Dark music like theirs won't ever be considered a pop, but they have just as many fans and longer-lasting popularity.
""",
"""
The Beach Boys rode the wave of the California Sound of surf rock and then evolved into more personal themes as their fan base also matured. Their music's orchestrations and arrangements became so complex that, like the Moody Blues, they couldn't perform it faithfully live on stage. Their vocal harmonies were recorded in one take early on and are absolute perfection that few achieve today. They're one of the few bands that found success before the British Invasion and maintained it during and after that period. These guys were deeply spiritual and if you listen closely you can hear it in the lyrics.
""",
"""
 Part of reaching a wide audience is having a wide appeal. Led Zeppelin played music in the blues-rock and folk-rock genres but are also thought of as progenitors of heavy metal, too. Possibly the most influential and popular song in rock history is their single Stairway to Heaven. These guys did it big, every time. The concerts broke records for people in attendance. Their albums rank among the top-selling ever. Each of their nine total albums reached the top 10 and six reached the number-one slot on the charts. They've earned all of the music awards available. Their legacy is everlasting among musicians and fans alike.
""",
"""
 U2 formed as a crew of friends in secondary school in Dublin, Ireland before any of them had any real proficiencies with music. Within four years they scored a record deal. By their fifth album, they became a global sensation. At the present, they've won 22 Grammy Awards, more than any other band, period. Part of their success is every time they run into controversy or boredom from their fan base, they evolve and revolutionize their sound. They're huge experimenters, and The Edge really exemplifies this with his guitar pedal array.
""",
"""
 If you're like me, you may be thinking ",why, though?" The Who has a huge appeal, with their pop art and mod subculture influences and even more so thanks to their rock opera Tommy and its success. I like any concept album and theirs is great. The tours were enormous and exciting, which helped amplify the hype surrounding them. It's not just their music. They contributed to the development of the Marshall stack, the use of the synthesizer in rock, the use of large PA systems, and even down to things like power chords on the guitar. Musicians appreciate them more than fans and cite them regularly as a top influence, and fans have to respect their favorite artists' opinions.
""",
"""
Nirvana's breakout star was undoubtedly Kurt Cobain, and since his passing and the breakup of the band in 1994, Dave Grohl has gone on to be a musical great, playing the drums, bass, and singing vocals for countless bands and collaborations. It was Smells Like Teen Spirit that launched them to stardom in 1991. It didn't take long for them to win all of the music awards in rapid succession, even being inducted into the Rock and Roll Hall of Fame in the first year of their eligibility in 2014. It took the strength of their Nevermind album to finally knock Michael Jackson's Dangerous from the top spot on the Billboard charts.
""",
"""
The Doors were active from 1965 to 1973, a short eight-year run, but quickly became one of the most influential bands of the counter-culture era and a largely controversial band due to Jim Morrison's erratic behavior. Every decade has had a revival in interest in the band and new fans added, due to cover songs becoming popular, usage of their songs in hit movies, movies about them, etc.Their first album The Doors re-entered the Billboard charts 14 years after its initial release as did their greatest hits and best of albums. Their legacy will live on this way forever, it seems, as it should. They even created a brand new song in 2012 with Skrillex of all people, called "Breakn' a Sweat.
""",
"""
Queen already earned their slot on this list but lately, they're gaining even more ground. Since 1970 they've not stopped touring and creating new music, albeit with new vocalists since Freddy Mercury passed. They're name may be Queen but they're the kings of arena rock and pop rock. They're songs are still over-played today to the point where many of us are about sick of them. If you've been to a sporting event, you've undoubtedly heard their anthems chanted by those in attendance to intimidate the opposing team. The work they did for the Flash Gordon and Highlander makes them some of the best soundtracks ever. There was even a biographical movie made about the band recently. That's a big time.
"""
    ]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "FAMOUS BANDS OF ALL TIMES"
        bandsArray = [bandsList(bandName: "The Beatles", bandImage:"the-beatles"), bandsList(bandName: "The Rolling Stones", bandImage: "the-rolling-stones"), bandsList(bandName: "Pink Floyd", bandImage: "pink-floyd"),bandsList(bandName: "The Beach Boys", bandImage: "the-beach-boys"),bandsList(bandName: "Led Zeppelin", bandImage: "led-zeppelin"), bandsList(bandName: "U2", bandImage: "u2"),bandsList(bandName: "The Who", bandImage: "the-who"),bandsList(bandName: "Nirvana", bandImage: "nirvana"),bandsList(bandName: "The Doors", bandImage: "the-doors"),bandsList(bandName: "Queen", bandImage: "queen")
        ]
      
       
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension TabTwoViewController: UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bandsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TabTwoTableViewCell", for: indexPath) as! TabTwoTableViewCell
        let data = bandsArray[indexPath.row]
        cell.nameOfband?.text = data.bandName
        cell.imageOfBand?.image = UIImage(named: data.bandImage)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        //_ = bandsArray[indexPath.row]
        vc.infoShow = textDetails[indexPath.row]
        //vc.infoShow = bandsArray[indexPath.row].bandName
        vc.imageShow = bandsArray[indexPath.row].bandImage
        //delegate?.details(info1:textDetails[1],info2:data.bandImage)
        navigationController?.pushViewController(vc, animated: true)
    }
    

}

struct bandsList {
    var bandName: String
    var bandImage: String
}

