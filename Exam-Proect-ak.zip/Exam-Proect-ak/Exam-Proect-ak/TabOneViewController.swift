//
//  TabOneViewController.swift
//  Exam-Proect-ak
//
//  Created by Cosultant on 8/26/22.
//

import UIKit

class TabOneViewController: UIViewController {
   
    @IBOutlet var homeImage:UIImageView?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        homeImage?.image = UIImage(named: "set-of-rock-and-roll-music-symbols-with-drums-plectrum-and-machete-labels-logos-heavy-metal-templates-for-design-t-shirt-night-party-and-festival-hand-drawn-engraved-sketch-R2NFYA")
        // Do any additional setup after loading the view.
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
