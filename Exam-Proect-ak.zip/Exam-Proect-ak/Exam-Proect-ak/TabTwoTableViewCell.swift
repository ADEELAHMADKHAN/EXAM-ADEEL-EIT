//
//  TabTwoTableViewCell.swift
//  Exam-Proect-ak
//
//  Created by Cosultant on 8/26/22.
//

import UIKit

class TabTwoTableViewCell: UITableViewCell {
   
    @IBOutlet weak var nameOfband: UILabel?
    @IBOutlet weak var imageOfBand: UIImageView?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}


