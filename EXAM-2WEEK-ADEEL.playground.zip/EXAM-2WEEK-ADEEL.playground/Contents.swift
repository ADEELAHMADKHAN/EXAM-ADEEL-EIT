import UIKit


var Array = [20,30,30,50,42,49,89,78,78,78]

if Array.count < 2
{print("nil")}
    else
{Array.sort()
        
        print(Array)
        
        print("The Second Larges number in the array is")
        
        let a = Array.count - 2
        print(Array[a])
    }
        




